package com.java.assignment;
import java.util.*;


public class getPermutation 
 {
		// Function to find the
		// kth permutation of n numbers
	static String findKthPermutation(int n, int k)
	{
		String str = "";
		List<String> result = new ArrayList<String>();

		// Insert all natural number
		// upto n in string
		for (int i = 1; i <= n; i++) 
		{
			str += i;
		}
		generate_permutations(str, 0, result);

		// sort the generated permutations
		Collections.sort(result);

		// make k 0-based indexed to point to kth sequence
		return result.get(k - 1);
	}
	
	static char[] swap(String s, int i, int j)
	{
		char[] ch = s.toCharArray();
		char temp = ch[i];
		ch[i] = ch[j];
		ch[j] = temp;
		return ch;
	}

	// recursive function to generate all
	// possible permutations of a string
	static void generate_permutations(String str, int idx,List<String> result)
	{
		// base case
		if (idx == str.length()) 
		{
			result.add(str);
			return;
		}

		// traverse string from idx to end
		for (int i = idx; i < str.length(); i++)
		{
			str = new String(swap(str, i, idx));
			generate_permutations(str, idx + 1, result);
			str = new String(swap(str, i, idx));
		}
	}

		// Calling code
		public static void main(String[] args)
		{
			int n = 3, k = 3;
			String kth_perm_seq = findKthPermutation(n, k);

			// function call
			System.out.println(kth_perm_seq);
		}

}