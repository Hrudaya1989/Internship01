package com.java.assignment;

public class searchArray
{

//Function to find insert position of K
public static int Searchindex(int[] Arr, int n, int K)
{	
	// Traverse the array
	for(int i = 0; i < n; i++)	
		// If K is found
		if (Arr[i] == K)
			return i;
		// If current array element
		// exceeds K
		else if (Arr[i] > K)
			return i;

	// If all elements are smaller
	// than K
	return n;
}

//Calling Code
public static void main(String[] args)
{
	int[] arr = { 1, 3, 5, 6 };
	int n = arr.length;
	int K = 5;
	
	System.out.println(Searchindex(arr, n, K));
}
}
