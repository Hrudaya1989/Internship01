package com.java.assignment;


public class SumOf2DArray 
{
	// Function to calculate sum of elements in 2d array
	public static int Findsum(int[][] arr) 
	{
		int ans = 0;
		int M = arr.length;
		int N = arr[0].length;

		// Finding the sum
		for (int i = 0; i < M; i++)
		{
			for (int j = 0; j < N; j++) 
			{
				ans += arr[i][j];
			}
		}

		return ans;
	}

	public static void main(String args[]) 
	{
		// Get the size m and n
		int M = 4;
		int N = 4;
		int x = 1;
		int[][] arr = new int[M][N];

		// Get the matrix elements
		for (int i = 0; i < M; i++)
		{
			for (int j = 0; j < N; j++)
			{
				arr[i][j] = x;
				x++;
			}
		}

		// Get sum
		System.out.println(Findsum(arr));
	}
}
