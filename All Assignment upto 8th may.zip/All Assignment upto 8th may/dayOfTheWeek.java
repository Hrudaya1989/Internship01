package com.java.assignment;
import java.time.*;
import java.time.DayOfWeek;


public class dayOfTheWeek 

{
	public static void main(String[] args)
	{
		// Set a local date whose day is found
		LocalDate localDate	= LocalDate.of(1947,Month.AUGUST,16);

		// Find the day from the local date
		DayOfWeek dayOfWeek	= DayOfWeek.from(localDate);

		// Printing the day of the week
		System.out.println("Week day is "+ dayOfWeek.name());
	}
}
