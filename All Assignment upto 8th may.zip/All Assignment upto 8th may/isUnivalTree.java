package com.java.assignment;

public class isUnivalTree 

{

//Structure of a tree node
static class Node
{
	int data;
	Node left;
	Node right;
};

//Function to insert a new node
//in a binary tree
static Node newNode(int data)
{
	Node temp = new Node();
	temp.data = data;
	temp.left = temp.right = null;
	return (temp);
}

//Function to check If the tree
//is uni-valued or not
static boolean isUnivalTree1(Node root)
{

	// If tree is an empty tree
	if (root == null)
	{
		return true;
	}

	// If all the nodes on the left subtree
	// have not value equal to root node
	if (root.left != null
		&& root.data != root.left.data)
		return false;

	// If all the nodes on the left subtree
	// have not value equal to root node
	if (root.right != null
		&& root.data != root.right.data)
		return false;

	// Recurse on left and right subtree
	return isUnivalTree1(root.left)
		&& isUnivalTree1(root.right);
}

//Driver Code
public static void main(String[] args)
{

	Node root = newNode(1);
	root.left = newNode(1);
	root.right = newNode(1);
	root.left.left = newNode(1);
	root.left.right = newNode(1);
	root.right.right = newNode(1);

	if (isUnivalTree1(root))
	{
		System.out.print("YES");
	}
	else
	{
		System.out.print("NO");
	}
}
}
