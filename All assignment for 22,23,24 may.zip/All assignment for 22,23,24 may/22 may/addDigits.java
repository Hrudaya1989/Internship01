package com.java.assignment;

public class addDigits 
{

	static int digSum(int n)
	{
		if (n == 0)
		return 0;
		return (n % 9 == 0) ? 9 : (n % 9);
	}
	
	// Driver program to test the above function
	public static void main (String[] args)
	{
		int n = 1234;
		System.out.println(digSum(n));
	}
}
