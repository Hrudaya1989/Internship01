package com.java.assignment;
import java.util.ArrayList;
import java.util.List;

public class isAdditiveNumber 
{
	// Checks whether num is valid or not, by checking first character and size
	
	private static boolean isValid(String num)
	{
		if (num.length() > 1 && num.charAt(0) == '0')
			return false;
		return true;
	}

	// returns int value at pos string, if pos is out of bound then returns 0
	
	private static int val(String a, int pos)
	{
		if (pos >= a.length() || pos < 0)
			return 0;

		// converting character to integer
		return (a.charAt(pos) - '0');
	}

	// add two number in string form and return result as a string
	
	private static String addString(String a, String b)
	{
		StringBuilder sum = new StringBuilder();
		int i = a.length() - 1;
		int j = b.length() - 1;
		int carry = 0;

		// loop until both string get processed
		while (i >= 0 || j >= 0)
		{
			int t = val(a, i) + val(b, j) + carry;
			sum.append(t % 10);
			carry = t / 10;
			i--;
			j--;
		}
		if (carry > 0)
			sum.append(carry);
		return sum.reverse().toString();
	}

	// Recursive method to check c = a + b
	private static boolean checkAddition(List<String> res,String a, String b,String c)
	{
		// both first and second number should be valid
		if (!isValid(a) || !isValid(b))
			return false;
		String sum = addString(a, b);

		// if sum is same as c then direct return
		if (sum.equals(c))
		{
			res.add(sum);
			return true;
		}

		/* if sum size is greater than c, then no possible sequence further OR if c is 
		 not prefix of sum string, then no possible	sequence further */
		if (c.length() <= sum.length()|| !sum.equals(c.substring(0, sum.length())))
			
			return false;
		else 
		{
			res.add(sum);

			// next recursive call will have b as first
			// number, sum as second number and string
			// c as third number after removing prefix
			// sum string from c
			return checkAddition(res, b, sum,c.substring(sum.length()));
		}
	}

	// Method returns additive sequence from string as a list
	public static List<String> additiveSequence(String num)
	{
		List<String> res = new ArrayList<>();
		int l = num.length();

		// loop until l/2 only, because if first number is larger,then no possible sequence  later
		for (int i = 1; i <= l / 2; i++) 
		{
			for (int j = 1; j <= (l - i) / 2; j++) 
			{
				if (checkAddition(res, num.substring(0, i),
								num.substring(i, i + j),
								num.substring(i + j)))
				{
					// adding first and second number at
					// front of result list
					res.add(0, num.substring(0, i));
					res.add(1, num.substring(i, i + j));
					return res;
				}
			}
		}

		// If code execution reaches here, then string
		// doesn't have any additive sequence
		res.clear();
		return res;
	}

	// Method to print result list

	// Driver code to test above methods
	public static void main(String[] args)
	{
		String num = "235813";
		List<String> res = additiveSequence(num);
		if (res.size() > 0)
			System.out.println( "True");
		else
		System.out.println( "False");
		num = "199100199";
		res = additiveSequence(num);
		if (res.size() > 0)
			System.out.println( "True");
		else
		System.out.println( "True");
	}
}
