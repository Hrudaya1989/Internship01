package com.java.assignment;

public class isPowerOfThree 
{
static boolean isPower_of_Three(long n)
{
	if (n <= 0)
		return false;
	if (n % 3 == 0)
		return isPower_of_Three(n / 3);
	if (n == 1)
		return true;
	return false;
}

// Driver code
public static void main(String[] args)
{
	long num1 = 80;
	if (isPower_of_Three(num1))
		System.out.print("TRUE");
	else
		System.out.print("False" );
}
}