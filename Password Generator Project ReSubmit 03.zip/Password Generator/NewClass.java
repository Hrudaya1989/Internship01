package com.java.internship;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class NewClass
{
	public static void main(String[] args)
	{
		
		ThreadLocalRandom random = ThreadLocalRandom.current();
		int length = random.nextInt(8, 16);
		System.out.println(Password(length));
		System.out.println("Your password strength: " + getPasswordStrength(length));
		
	}
	static char[] Password(int len)
	{
		System.out.println("Generating password using random() : " + len);
		System.out.print("Your new password is : ");
		String Capital_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String Small_chars = "abcdefghijklmnopqrstuvwxyz";
		String numbers = "0123456789";
		String symbols = "!@#$%^&*_=+-/.?<>)(";
		String values = Capital_chars + Small_chars + numbers + symbols;

		Random rndm_method = new Random();
		

		char[] Password = new char[len];

		for (int i = 0; i < len; i++)
		{
			Password[i] =values.charAt(rndm_method.nextInt(values.length()));
		}
		return Password;
	}
	public static String getPasswordStrength(int length) 
	{
		if(length <8) {
			return "weak";
		} else if(length < 16) {
			return "medium";
		} else {
			return "strong";
		}
	}
	
}
