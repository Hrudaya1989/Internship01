package com.java.internship;

import java.util.Scanner;

public class JavaApplication {
	    
	    static String password_strength(String password) 
	    {
	        int strength = 0; 
	        if (password.length()==0) 
	        {
	            strength = password.length();
	        }
	        if (password.matches(".*[A-Z].*")) 
	        {
	            strength = password.length();
	        }
	        if (password.matches(".*[a-z].*")) 
	        {
	            strength = password.length();
	        }
	        if (password.matches(".*[0-9].*")) 
	        {
	            strength = password.length();
	        }
	        if (password.matches(".*[!@#$%^&*()_+-/.,<>?;':\"{}\\|`~].*")) 
	        {
	            strength = password.length();
	        }
	        if (strength <=7) 
	        {
	            return "Very Weak";
	        } 
	        else if (strength == 8) 
	        {
	            return "Weak";
	        } 
	        else if (strength >=9 && strength <=15) 
	        {
	            return "Medium";
	        }
	        else if (strength == 16)
	        {
	            return "Strong";
	        } 
	        else if (strength > 17)
	        {
	            return "Very Strong";
	        }
	        return "Very Weak";
	    }

	    public static void main(String[] args)
	    {
	        Scanner sc = new Scanner(System.in);
	        System.out.print("Type your password: ");
	        String password = sc.nextLine();
	        sc.close();
	        System.out.println("Password Strength: " + password_strength(password));
	    }
	}