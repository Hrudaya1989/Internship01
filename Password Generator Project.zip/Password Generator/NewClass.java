package com.java.internship;

import java.util.*;

public class NewClass
{
	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter a length");
		int length=s.nextInt();
		System.out.println(Password(length));
	}
	static char[] Password(int len)
	{
		System.out.println("Generating password using random() : ");
		System.out.print("Your new password is : ");
		String Capital_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String Small_chars = "abcdefghijklmnopqrstuvwxyz";
		String numbers = "0123456789";
		String symbols = "!@#$%^&*_=+-/.?<>)(";


		String values = Capital_chars + Small_chars +
						numbers + symbols;

		Random rndm_method = new Random();

		char[] Password = new char[len];

		for (int i = 0; i < len; i++)
		{
			Password[i] =
			values.charAt(rndm_method.nextInt(values.length()));

		}
		return Password;
	}
}
