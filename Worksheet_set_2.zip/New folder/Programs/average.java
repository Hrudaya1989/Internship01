package com.java.internship;
import java.util.*;
public class average 
{
	
	    public static void main(String args[]) {
	       
	        int n1, n2, sum;
	        float avg;
	        
	        Scanner s = new Scanner(System.in);
	        
	        System.out.print("Enter first number : ");
	        n1 = s.nextInt();
	   
	        System.out.print("Enter second number : ");
	        n2 = s.nextInt();
	 
	        
	        sum = n1 + n2;
	        avg = (float)((n1 + n2) / 2);
	        
	        System.out.print("Sum : " + sum + "\nAverage : " + avg);
	    }
	}


