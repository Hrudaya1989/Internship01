package com.java.internship;

import java.util.Scanner;

public class greatestNum 
{

	 public static void main(String[] args)
	   {
	      int a, b, c, large;
	      
	      Scanner S = new Scanner(System.in);
	      
	      System.out.print("Enter the First Number: ");
	      a = S.nextInt();
	      System.out.print("Enter the Second Number: ");
	      b = S.nextInt();
	      System.out.print("Enter the Third Number: ");
	      c = S.nextInt();
	      
	      if(a>b && a>c)
	         large = a;
	      else if(b>a && b>c)
	         large = b;
	      else
	         large = c;
	      
	      System.out.println("\nLargest = " +large);
	   }
	}
	

