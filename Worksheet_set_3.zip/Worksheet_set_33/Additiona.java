package com.java.internship;

import java.util.Scanner;

public class Additiona 
{
	public static void main(String[] args)
	   {
	      int a, b, sum=0;
	      Scanner sc = new Scanner(System.in);
	      System.out.println("Enter First number : ");
	      a = sc.nextInt();
	      System.out.println("Enter Second number : ");
	      b = sc.nextInt();
	      sum = addTwoInt(a, b);
	      System.out.println("Sum = " + sum);
	      sc.close();
	   }
	   public static int addTwoInt(int a, int b)
	   {
	      int sum = a + b;
	      return sum;
	   }
}