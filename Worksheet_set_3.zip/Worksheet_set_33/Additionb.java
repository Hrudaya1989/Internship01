package com.java.internship;

import java.util.Scanner;

public class Additionb 
{
	static int a,b,sum=0;
	 
	public void addTwoInt(int a, int b)
	{
		Scanner sc = new Scanner(System.in); 
		System.out.print("Enter the First  Number: ");
	    a = sc.nextInt(); 
		System.out.print("Enter the second number: "); 
		b = sc.nextInt();
		
		sum = a + b ; 
		System.out.println("The sum of two numbers x and y is: " + sum);
		
	}

	public static void main(String args[])  
	{  
		Additionb obj = new Additionb();
		obj.addTwoInt(a,b);
	}
}