package com.java.internship;
import java.io.*;

class example
{
	private String name;
	private int number;
	
	public int getter() 
	{ 
		return number;
	}
	public void setter(int a)
	{
		this.number = a;
	}
	
	public String getter1() 
	{ 
		return name;
	}
	public void setter(String b)
	{
		this.name = b;
	}

	public static void main(String[] args)
	{
		
		example obj = new example();
		obj.setter("Name is : Abhinash");
		obj.setter(10);
		System.out.println(obj.getter1() + " \n " + obj.getter());
	}

}